/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 11);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("/* harmony export (immutable) */ __webpack_exports__[\"c\"] = log;\n/* unused harmony export warn */\n/* harmony export (immutable) */ __webpack_exports__[\"b\"] = error;\n/* harmony export (immutable) */ __webpack_exports__[\"d\"] = perfMark;\n/* harmony export (immutable) */ __webpack_exports__[\"e\"] = perfMarkEnd;\n/* unused harmony export logSince */\nconst LOG_LEVELS = {\n  log: 1,\n  warn: 2,\n  error: 3,\n};\n/* harmony export (immutable) */ __webpack_exports__[\"a\"] = LOG_LEVELS;\n\n\nlet _logLevelIndex = LOG_LEVELS.warn;\nlet perfAvailable;\n\nconst logCommand = (levelName, levelIndex, args) => {\n  if (levelIndex >= _logLevelIndex) {\n    console[levelName].apply(console, args);\n  }\n};\n\nfunction log() {\n  logCommand(\"log\", 1, arguments);\n}\nfunction warn() {\n  logCommand(\"warn\", 2, arguments);\n}\nfunction error() {\n  logCommand(\"error\", 3, arguments);\n}\n\nconst checkIfPerformanceAvailable = () => {\n  perfAvailable = !!(LOG_LEVELS.log && window.performance && window.performance.measure);\n};\ncheckIfPerformanceAvailable();\n\nfunction perfMeasure(name, marker1, marker2) {\n  _logLevelIndex === LOG_LEVELS.log && window.performance.measure(name, marker1, marker2);\n}\n\nfunction perfMark(marker) {\n  _logLevelIndex === LOG_LEVELS.log && window.performance.mark(marker);\n}\n\nfunction perfMarkEnd(name, marker1, marker2) {\n  if (_logLevelIndex === LOG_LEVELS.log) {\n    const markerEnd = marker2 || marker1 + \" - end\";\n    perfMark(markerEnd);\n    perfMeasure(name, marker1, markerEnd);\n  }\n}\n\nconst setLogLevel = logLevel => {\n  _logLevelIndex = logLevel;\n  checkIfPerformanceAvailable();\n};\n/* harmony export (immutable) */ __webpack_exports__[\"f\"] = setLogLevel;\n\n\nconst timers = {};\nfunction logSince(timer, message) {\n  if (timers[timer] === undefined) {\n    timers[timer] = performance && performance.now();\n  }\n  log(`timing: (${performance.now() - timers[timer]}) ${message}`);\n}\n\n\n//////////////////\n// WEBPACK FOOTER\n// ./src/logger.js\n// module id = 0\n// module chunks = 0 1 2\n\n//# sourceURL=webpack:///./src/logger.js?");

/***/ }),
/* 1 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__logger__ = __webpack_require__(0);\n/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__indexedDB__ = __webpack_require__(3);\n\n\n\nconst DB_NAME = \"RESOURCE_CACHE\";\nconst STORE_NAME = \"RESOURCES\";\nconst DB_VERSION = 4;\n\nlet resolvedPromise = null;\n\n/* harmony default export */ __webpack_exports__[\"a\"] = (function() {\n  if (resolvedPromise) {\n    return resolvedPromise;\n  }\n  const idbWrapper = Object.create(null);\n  let _db = null;\n  const req = __WEBPACK_IMPORTED_MODULE_1__indexedDB__[\"a\" /* default */].open(DB_NAME, DB_VERSION);\n\n  const store = (type = \"readwrite\") => {\n    const transaction = _db.transaction([STORE_NAME], type);\n    return transaction.objectStore(STORE_NAME);\n  };\n\n  idbWrapper.get = id =>\n    new Promise((resolve, reject) => {\n      const request = store(\"readonly\").get(id);\n      request.onsuccess = event => {\n        if (event.target.result) {\n          resolve(event.target.result);\n        } else {\n          __WEBPACK_IMPORTED_MODULE_0__logger__[\"c\" /* log */](`resource with id ${id} is not in the cache`);\n          reject(null);\n        }\n      };\n      request.onerror = event => {\n        reject(event);\n      };\n    });\n\n  idbWrapper.exists = id =>\n    new Promise((resolve, reject) => {\n      const request = store(\"readonly\").count(id);\n      request.onsuccess = e => {\n        const exists = e.target.result > 0;\n        if (exists) {\n          resolve({});\n        } else {\n          reject();\n        }\n      };\n      request.onerror = event => {\n        reject(event);\n      };\n    });\n\n  idbWrapper.removeResource = id =>\n    new Promise((resolve, reject) => {\n      const objectStore = store();\n      const request = objectStore.delete(id);\n      request.onsuccess = () => {\n        __WEBPACK_IMPORTED_MODULE_0__logger__[\"c\" /* log */](`removed resource ${id}`);\n        resolve();\n      };\n      request.onerror = e => {\n        __WEBPACK_IMPORTED_MODULE_0__logger__[\"b\" /* error */](`failed to remove resource ${id}. error: ${e}`);\n        reject(e);\n      };\n    });\n\n  idbWrapper.put = (id, { content, contentType }) =>\n    new Promise((resolve, reject) => {\n      const objectStore = store();\n      const putRequest = objectStore.put({\n        id,\n        content,\n        contentType,\n      });\n\n      putRequest.onsuccess = resolve;\n      putRequest.onerror = e => {\n        __WEBPACK_IMPORTED_MODULE_0__logger__[\"b\" /* error */](`failed to save item with id ${id} in cache due to error ${e}`);\n        reject();\n      };\n    });\n\n  idbWrapper.pruneDb = (knownIds = []) =>\n    new Promise((resolve, reject) => {\n      const objectStore = store();\n      const request = objectStore.openCursor();\n      request.onsuccess = e => {\n        const cursor = e.target.result;\n        if (cursor) {\n          if (!knownIds.includes(cursor.key)) {\n            idbWrapper.removeResource(cursor.key);\n            __WEBPACK_IMPORTED_MODULE_0__logger__[\"c\" /* log */](`pruned ${cursor.key}`);\n          }\n          cursor.continue();\n        } else {\n          resolve();\n        }\n      };\n      request.onerror = e => {\n        __WEBPACK_IMPORTED_MODULE_0__logger__[\"b\" /* error */](`failed to get all keys while pruning cache. error`);\n        reject(e);\n      };\n    });\n\n  resolvedPromise = new Promise((resolve, reject) => {\n    req.onsuccess = e => {\n      _db = e.target.result;\n      resolve(idbWrapper);\n    };\n    req.onupgradeneeded = e => {\n      const db = e.target.result;\n      db.createObjectStore(STORE_NAME, { keyPath: \"id\" });\n    };\n    req.onerror = e => {\n      __WEBPACK_IMPORTED_MODULE_0__logger__[\"b\" /* error */](\"failed to open indexedDB \" + JSON.stringify(e));\n      reject(e);\n    };\n  });\n  return resolvedPromise;\n});\n\nconst closeConnection = () => {\n  resolvedPromise = null;\n};\n/* unused harmony export closeConnection */\n\n\n\n//////////////////\n// WEBPACK FOOTER\n// ./src/indexedDBAccess.js\n// module id = 1\n// module chunks = 0 1 2\n\n//# sourceURL=webpack:///./src/indexedDBAccess.js?");

/***/ }),
/* 2 */,
/* 3 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("/* harmony default export */ __webpack_exports__[\"a\"] = (window.indexedDB);\n\n\n//////////////////\n// WEBPACK FOOTER\n// ./src/indexedDB.js\n// module id = 3\n// module chunks = 0 1 2\n\n//# sourceURL=webpack:///./src/indexedDB.js?");

/***/ }),
/* 4 */,
/* 5 */,
/* 6 */,
/* 7 */,
/* 8 */,
/* 9 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("const events = {};\n\nconst on = (eventName, handler) => {\n  if (events[eventName] === undefined) {\n    events[eventName] = [];\n  }\n  events[eventName].push(handler);\n};\n/* harmony export (immutable) */ __webpack_exports__[\"a\"] = on;\n\n\nconst trigger = eventName => {\n  if (events[eventName] !== undefined) {\n    events[eventName].forEach(handler => handler());\n  }\n};\n/* harmony export (immutable) */ __webpack_exports__[\"b\"] = trigger;\n\n\n\n//////////////////\n// WEBPACK FOOTER\n// ./src/eventBus.js\n// module id = 9\n// module chunks = 0 1 2\n\n//# sourceURL=webpack:///./src/eventBus.js?");

/***/ }),
/* 10 */,
/* 11 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("Object.defineProperty(__webpack_exports__, \"__esModule\", { value: true });\n/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__fetchToCache__ = __webpack_require__(13);\n/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__fetchToCache___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__fetchToCache__);\n/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__indexedDBAccess__ = __webpack_require__(1);\n/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__workerActions__ = __webpack_require__(14);\n/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__workerActions___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__workerActions__);\n/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__eventBus__ = __webpack_require__(9);\n/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__self__ = __webpack_require__(18);\n/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__self___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4__self__);\n\n\n\n\n\n\nconst FETCHING_COMPLETE = \"FETCHING_COMPLETE\";\n\nlet fetchingInFlight = 0;\ndebugger;\nfunction die() {\n\t__WEBPACK_IMPORTED_MODULE_4__self__[\"default\"].postMessage({ action: __WEBPACK_IMPORTED_MODULE_2__workerActions__[\"default\"].CLOSING, success: true, payload: {} });\n\tclose();\n}\n\n__WEBPACK_IMPORTED_MODULE_4__self__[\"default\"].addEventListener(\"message\", ({ data }) => {\n\t__WEBPACK_IMPORTED_MODULE_1__indexedDBAccess__[\"a\" /* default */]().then(idbAccess => {\n\t\tswitch (data.action) {\n\t\t\tcase __WEBPACK_IMPORTED_MODULE_2__workerActions__[\"default\"].FETCH:\n\t\t\t\t++fetchingInFlight;\n\t\t\t\tconst { url, isBinary } = data.payload;\n\t\t\t\t__WEBPACK_IMPORTED_MODULE_0__fetchToCache__[\"fetchAndSaveInCache\"]({ url, isBinary, indexedDBAccess: idbAccess })\n\t\t\t\t\t.then(() => {\n\t\t\t\t\t\t__WEBPACK_IMPORTED_MODULE_4__self__[\"default\"].postMessage({ action: __WEBPACK_IMPORTED_MODULE_2__workerActions__[\"default\"].FETCH_SUCCESS, success: true, payload: { url } });\n\t\t\t\t\t})\n\t\t\t\t\t.catch(error => {\n\t\t\t\t\t\t__WEBPACK_IMPORTED_MODULE_4__self__[\"default\"].postMessage({\n\t\t\t\t\t\t\taction: __WEBPACK_IMPORTED_MODULE_2__workerActions__[\"default\"].FETCH_FAIL,\n\t\t\t\t\t\t\tsuccess: false,\n\t\t\t\t\t\t\tpayload: { url, error: { status: error.status, statusText: error.statusText } },\n\t\t\t\t\t\t});\n\t\t\t\t\t})\n\t\t\t\t\t.then(() => {\n\t\t\t\t\t\t--fetchingInFlight;\n\t\t\t\t\t\tif (fetchingInFlight === 0) {\n\t\t\t\t\t\t\t__WEBPACK_IMPORTED_MODULE_3__eventBus__[\"b\" /* trigger */](FETCHING_COMPLETE);\n\t\t\t\t\t\t}\n\t\t\t\t\t});\n\t\t\t\treturn;\n\t\t\tcase __WEBPACK_IMPORTED_MODULE_2__workerActions__[\"default\"].CLOSE:\n\t\t\t\tif (fetchingInFlight === 0) {\n\t\t\t\t\tdie();\n\t\t\t\t} else {\n\t\t\t\t\t__WEBPACK_IMPORTED_MODULE_3__eventBus__[\"a\" /* on */](FETCHING_COMPLETE, die);\n\t\t\t\t}\n\t\t}\n\t});\n});\n\n\n//////////////////\n// WEBPACK FOOTER\n// ./src/fetchWorker.js\n// module id = 11\n// module chunks = 2\n\n//# sourceURL=webpack:///./src/fetchWorker.js?");

/***/ }),
/* 12 */,
/* 13 */
/***/ (function(module, exports) {

eval("throw new Error(\"Module build failed: Error: ENOENT: no such file or directory, open '/Users/elad/work/capriza/capp-cache/src/fetchToCache.js'\");\n\n//////////////////\n// WEBPACK FOOTER\n// ./src/fetchToCache.js\n// module id = 13\n// module chunks = 2\n\n//# sourceURL=webpack:///./src/fetchToCache.js?");

/***/ }),
/* 14 */
/***/ (function(module, exports) {

eval("throw new Error(\"Module build failed: Error: ENOENT: no such file or directory, open '/Users/elad/work/capriza/capp-cache/src/workerActions.js'\");\n\n//////////////////\n// WEBPACK FOOTER\n// ./src/workerActions.js\n// module id = 14\n// module chunks = 2\n\n//# sourceURL=webpack:///./src/workerActions.js?");

/***/ }),
/* 15 */,
/* 16 */,
/* 17 */,
/* 18 */
/***/ (function(module, __webpack_exports__) {

"use strict";
eval("throw new Error(\"Module build failed: Error: ENOENT: no such file or directory, open '/Users/elad/work/capriza/capp-cache/src/self.js'\");\n\n//////////////////\n// WEBPACK FOOTER\n// ./src/self.js\n// module id = 18\n// module chunks = 2\n\n//# sourceURL=webpack:///./src/self.js?");

/***/ })
/******/ ]);